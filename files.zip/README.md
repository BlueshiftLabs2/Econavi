# Econavi - AI-Powered Financial Management

Econavi is a comprehensive financial management software with AI-powered insights to help you take control of your finances.

## Features

- Secure user authentication
- Expense tracking with categorization
- Budget management
- AI-powered financial insights
- Bill payment reminders
- Data visualization and analytics
- Export functionality for financial data

## Setup & Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/econavi.git
cd econavi