    @staticmethod
    def update_password(user_id, password):
        """Update a user's password."""
        conn = get_db_connection()
        hashed_password = generate_password_hash(password)
        conn.execute(
            'UPDATE users SET password = ? WHERE id = ?',
            (hashed_password, user_id)
        )
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def delete(user_id):
        """Delete a user and all associated data."""
        conn = get_db_connection()
        
        # Delete all associated data
        conn.execute('DELETE FROM expenses WHERE user_id = ?', (user_id,))
        conn.execute('DELETE FROM budget WHERE user_id = ?', (user_id,))
        conn.execute('DELETE FROM income WHERE user_id = ?', (user_id,))
        conn.execute('DELETE FROM bills WHERE user_id = ?', (user_id,))
        
        # Delete the user
        conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
        
        conn.commit()
        conn.close()
        return True
        

class Expense:
    """Expense model class."""
    
    @staticmethod
    def create(user_id, amount, category, description, date):
        """Create a new expense."""
        conn = get_db_connection()
        conn.execute(
            'INSERT INTO expenses (user_id, amount, category, description, date) VALUES (?, ?, ?, ?, ?)',
            (user_id, amount, category, description, date)
        )
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def get_by_id(expense_id, user_id):
        """Get an expense by ID, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        expense = conn.execute(
            'SELECT * FROM expenses WHERE id = ? AND user_id = ?',
            (expense_id, user_id)
        ).fetchone()
        conn.close()
        return expense
    
    @staticmethod
    def get_recent(user_id, limit=10):
        """Get recent expenses for a user."""
        conn = get_db_connection()
        expenses = conn.execute(
            'SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC LIMIT ?',
            (user_id, limit)
        ).fetchall()
        conn.close()
        return expenses
    
    @staticmethod
    def get_by_date_range(user_id, start_date, end_date):
        """Get expenses within a date range for a user."""
        conn = get_db_connection()
        expenses = conn.execute(
            'SELECT * FROM expenses WHERE user_id = ? AND date >= ? AND date <= ? ORDER BY date DESC',
            (user_id, start_date, end_date)
        ).fetchall()
        conn.close()
        return expenses
    
    @staticmethod
    def get_by_category(user_id, category):
        """Get expenses for a specific category."""
        conn = get_db_connection()
        expenses = conn.execute(
            'SELECT * FROM expenses WHERE user_id = ? AND category = ? ORDER BY date DESC',
            (user_id, category)
        ).fetchall()
        conn.close()
        return expenses
    
    @staticmethod
    def get_category_totals(user_id):
        """Get total expenses by category for a user."""
        conn = get_db_connection()
        category_totals = conn.execute(
            'SELECT category, SUM(amount) as total FROM expenses WHERE user_id = ? GROUP BY category',
            (user_id,)
        ).fetchall()
        conn.close()
        return category_totals
    
    @staticmethod
    def get_total(user_id):
        """Get the total amount of all expenses for a user."""
        conn = get_db_connection()
        result = conn.execute(
            'SELECT SUM(amount) as total FROM expenses WHERE user_id = ?',
            (user_id,)
        ).fetchone()
        conn.close()
        return result['total'] if result['total'] else 0
    
    @staticmethod
    def delete(expense_id, user_id):
        """Delete an expense, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        conn.execute(
            'DELETE FROM expenses WHERE id = ? AND user_id = ?',
            (expense_id, user_id)
        )
        conn.commit()
        conn.close()
        return True


class Budget:
    """Budget model class."""
    
    @staticmethod
    def create(user_id, category, amount, period):
        """Create a new budget."""
        conn = get_db_connection()
        
        # Check if budget already exists for this category and period
        existing = conn.execute(
            'SELECT id FROM budget WHERE user_id = ? AND category = ? AND period = ?',
            (user_id, category, period)
        ).fetchone()
        
        if existing:
            # Update existing budget
            conn.execute(
                'UPDATE budget SET amount = ? WHERE id = ?',
                (amount, existing['id'])
            )
        else:
            # Create new budget
            conn.execute(
                'INSERT INTO budget (user_id, category, amount, period) VALUES (?, ?, ?, ?)',
                (user_id, category, amount, period)
            )
            
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def get_by_id(budget_id, user_id):
        """Get a budget by ID, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        budget = conn.execute(
            'SELECT * FROM budget WHERE id = ? AND user_id = ?',
            (budget_id, user_id)
        ).fetchone()
        conn.close()
        return budget
    
    @staticmethod
    def get_all(user_id):
        """Get all budgets for a user."""
        conn = get_db_connection()
        budgets = conn.execute(
            'SELECT * FROM budget WHERE user_id = ?',
            (user_id,)
        ).fetchall()
        conn.close()
        return budgets
    
    @staticmethod
    def get_by_category(user_id, category):
        """Get budgets for a specific category."""
        conn = get_db_connection()
        budgets = conn.execute(
            'SELECT * FROM budget WHERE user_id = ? AND category = ?',
            (user_id, category)
        ).fetchall()
        conn.close()
        return budgets
    
    @staticmethod
    def update(budget_id, user_id, amount, period):
        """Update a budget."""
        conn = get_db_connection()
        conn.execute(
            'UPDATE budget SET amount = ?, period = ? WHERE id = ? AND user_id = ?',
            (amount, period, budget_id, user_id)
        )
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def delete(budget_id, user_id):
        """Delete a budget, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        conn.execute(
            'DELETE FROM budget WHERE id = ? AND user_id = ?',
            (budget_id, user_id)
        )
        conn.commit()
        conn.close()
        return True


class Income:
    """Income model class."""
    
    @staticmethod
    def create(user_id, amount, source, description, date):
        """Create a new income record."""
        conn = get_db_connection()
        conn.execute(
            'INSERT INTO income (user_id, amount, source, description, date) VALUES (?, ?, ?, ?, ?)',
            (user_id, amount, source, description, date)
        )
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def get_by_id(income_id, user_id):
        """Get an income record by ID, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        income = conn.execute(
            'SELECT * FROM income WHERE id = ? AND user_id = ?',
            (income_id, user_id)
        ).fetchone()
        conn.close()
        return income
    
    @staticmethod
    def get_recent(user_id, limit=10):
        """Get recent income records for a user."""
        conn = get_db_connection()
        incomes = conn.execute(
            'SELECT * FROM income WHERE user_id = ? ORDER BY date DESC LIMIT ?',
            (user_id, limit)
        ).fetchall()
        conn.close()
        return incomes
    
    @staticmethod
    def get_total(user_id):
        """Get the total amount of all income for a user."""
        conn = get_db_connection()
        result = conn.execute(
            'SELECT SUM(amount) as total FROM income WHERE user_id = ?',
            (user_id,)
        ).fetchone()
        conn.close()
        return result['total'] if result['total'] else 0
    
    @staticmethod
    def delete(income_id, user_id):
        """Delete an income record, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        conn.execute(
            'DELETE FROM income WHERE id = ? AND user_id = ?',
            (income_id, user_id)
        )
        conn.commit()
        conn.close()
        return True


class Bill:
    """Bill model class."""
    
    @staticmethod
    def create(user_id, name, amount, due_date, category, is_recurring=False, recurrence_period=None):
        """Create a new bill."""
        conn = get_db_connection()
        conn.execute(
            '''INSERT INTO bills 
               (user_id, name, amount, due_date, category, is_recurring, recurrence_period) 
               VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (user_id, name, amount, due_date, category, is_recurring, recurrence_period)
        )
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def get_by_id(bill_id, user_id):
        """Get a bill by ID, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        bill = conn.execute(
            'SELECT * FROM bills WHERE id = ? AND user_id = ?',
            (bill_id, user_id)
        ).fetchone()
        conn.close()
        return bill
    
    @staticmethod
    def get_all(user_id):
        """Get all bills for a user."""
        conn = get_db_connection()
        bills = conn.execute(
            'SELECT * FROM bills WHERE user_id = ? ORDER BY due_date ASC',
            (user_id,)
        ).fetchall()
        conn.close()
        return bills
    
    @staticmethod
    def get_upcoming(user_id, days=30):
        """Get upcoming bills due within the specified number of days."""
        conn = get_db_connection()
        today = datetime.date.today().isoformat()
        future = (datetime.date.today() + datetime.timedelta(days=days)).isoformat()
        
        bills = conn.execute(
            'SELECT * FROM bills WHERE user_id = ? AND due_date BETWEEN ? AND ? ORDER BY due_date ASC',
            (user_id, today, future)
        ).fetchall()
        conn.close()
        return bills
    
    @staticmethod
    def update(bill_id, user_id, name, amount, due_date, category, is_recurring, recurrence_period):
        """Update a bill."""
        conn = get_db_connection()
        conn.execute(
            '''UPDATE bills 
               SET name = ?, amount = ?, due_date = ?, category = ?, 
                   is_recurring = ?, recurrence_period = ?
               WHERE id = ? AND user_id = ?''',
            (name, amount, due_date, category, is_recurring, recurrence_period, bill_id, user_id)
        )
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def delete(bill_id, user_id):
        """Delete a bill, ensuring it belongs to the specified user."""
        conn = get_db_connection()
        conn.execute(
            'DELETE FROM bills WHERE id = ? AND user_id = ?',
            (bill_id, user_id)
        )
        conn.commit()
        conn.close()
        return True