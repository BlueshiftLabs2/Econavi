import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Base configuration class."""
    SECRET_KEY = os.environ.get('SECRET_KEY') or os.urandom(24)
    GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
    DATABASE_PATH = 'econavi.db'
    DEBUG = False
    TESTING = False
    
class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    
class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    DATABASE_PATH = 'econavi_test.db'
    
class ProductionConfig(Config):
    """Production configuration."""
    # In a real application, you would configure production settings here
    pass

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}