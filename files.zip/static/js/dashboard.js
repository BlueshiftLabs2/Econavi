document.addEventListener('DOMContentLoaded', function() {
    // Initialize variables
    const addExpenseBtn = document.getElementById('add-expense-btn');
    const expenseModal = document.getElementById('expense-modal');
    const modalClose = document.querySelector('.modal-close');
    const expenseForm = document.getElementById('expense-form');
    const aiForm = document.getElementById('ai-form');
    const aiMessages = document.getElementById('ai-messages');
    
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('expense-date').value = today;
    
    // Initialize expense chart if categories exist
    initializeExpenseChart();
    
    // Modal controls
    addExpenseBtn.addEventListener('click', () => {
        expenseModal.style.display = 'flex';
    });
    
    modalClose.addEventListener('click', () => {
        expenseModal.style.display = 'none';
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === expenseModal) {
            expenseModal.style.display = 'none';
        }
    });
    
    // Handle expense form submission
    expenseForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(expenseForm);
        
        fetch('/add-expense', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Close modal and reset form
                expenseModal.style.display = 'none';
                expenseForm.reset();
                document.getElementById('expense-date').value = today;
                
                // Reload page to show new expense
                window.location.reload();
            } else {
                alert('Error adding expense: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while adding the expense');
        });
    });
    
    // Handle AI assistant form submission
    aiForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const query = document.getElementById('ai-query').value;
        const userMessage = document.createElement('div');
        userMessage.className = 'user-message';
        userMessage.innerHTML = `<p>${query}</p>`;
        aiMessages.appendChild(userMessage);
        
        // Clear input
        document.getElementById('ai-query').value = '';
        
        // Add loading message
        const loadingMessage = document.createElement('div');
        loadingMessage.className = 'ai-message';
        loadingMessage.innerHTML = '<p>Thinking...</p>';
        aiMessages.appendChild(loadingMessage);
        
        // Scroll to bottom
        aiMessages.scrollTop = aiMessages.scrollHeight;
        
        // Send request to AI
        fetch('/ask-ai', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `query=${encodeURIComponent(query)}`
        })
        .then(response => response.json())
        .then(data => {
            // Remove loading message
            aiMessages.removeChild(loadingMessage);
            
            // Add AI response
            const aiResponse = document.createElement('div');
            aiResponse.className = 'ai-message';
            aiResponse.innerHTML = `<p>${data.response}</p>`;
            aiMessages.appendChild(aiResponse);
            
            // Scroll to bottom
            aiMessages.scrollTop = aiMessages.scrollHeight;
        })
        .catch(error => {
            console.error('Error:', error);
            
            // Remove loading message
            aiMessages.removeChild(loadingMessage);
            
            // Add error message
            const errorMessage = document.createElement('div');
            errorMessage.className = 'ai-message error';
            errorMessage.innerHTML = '<p>Sorry, I encountered an error. Please try again.</p>';
            aiMessages.appendChild(errorMessage);
            
            // Scroll to bottom
            aiMessages.scrollTop = aiMessages.scrollHeight;
        });
    });
    
    // Initialize expense chart
    function initializeExpenseChart() {
        const ctx = document.getElementById('expense-chart');
        
        // Check if categories exist
        if (!ctx) return;
        
        // Get category data from the page
        const categories = Array.from(document.querySelectorAll('.expense-table tbody tr')).map(row => {
            return {
                category: row.cells[1].textContent,
                amount: parseFloat(row.cells[3].textContent.replace('$', ''))
            };
        });
        
        // Group by category and sum amounts
        const categoryData = {};
        categories.forEach(item => {
            if (categoryData[item.category]) {
                categoryData[item.category] += item.amount;
            } else {
                categoryData[item.category] = item.amount;
            }
        });
        
        // Create chart
        if (Object.keys(categoryData).length > 0) {
            const chart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: Object.keys(categoryData),
                    datasets: [{
                        data: Object.values(categoryData),
                        backgroundColor: [
                            '#4C6FFF', '#4ADEDE', '#797EF6', '#2E5BFF', '#18C8FF',
                            '#95B4FF', '#C9D4FF', '#F0F3FF', '#6E84A3', '#FF6B6B'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    },
                    cutout: '70%'
                }
            });
        }
        
        // Calculate and display totals
        if (categories.length > 0) {
            const totalExpenses = categories.reduce((total, item) => total + item.amount, 0);
            document.getElementById('total-expenses').textContent = `$${totalExpenses.toFixed(2)}`;
            
            // This would need to be updated with actual budget data
            // For now, using a placeholder
            document.getElementById('budget-remaining').textContent = '$1,000.00';
            document.getElementById('total-savings').textContent = '$500.00';
        }
    }
});