            fetch('/update-notifications', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Notification settings updated successfully');
                } else {
                    alert('Error updating notification settings: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating notification settings');
            });
        });
    }
    
    // Handle budget form submission
    if (budgetForm) {
        budgetForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(budgetForm);
            
            fetch('/add-budget', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Close modal and reset form
                    budgetModal.style.display = 'none';
                    budgetForm.reset();
                    
                    // Reload page to show new budget
                    window.location.reload();
                } else {
                    alert('Error adding budget: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while adding the budget');
            });
        });
    }
    
    // Edit budget buttons
    const editBudgetButtons = document.querySelectorAll('.edit-budget');
    editBudgetButtons.forEach(button => {
        button.addEventListener('click', function() {
            const budgetId = this.getAttribute('data-id');
            
            // Fetch budget details
            fetch(`/budget/${budgetId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Populate form with budget data
                    document.getElementById('budget-category').value = data.budget.category;
                    document.getElementById('budget-amount').value = data.budget.amount;
                    document.getElementById('budget-period').value = data.budget.period;
                    
                    // Add budget ID as hidden input
                    let hiddenInput = document.getElementById('budget-id');
                    if (!hiddenInput) {
                        hiddenInput = document.createElement('input');
                        hiddenInput.type = 'hidden';
                        hiddenInput.id = 'budget-id';
                        hiddenInput.name = 'id';
                        budgetForm.appendChild(hiddenInput);
                    }
                    hiddenInput.value = budgetId;
                    
                    // Show modal
                    budgetModal.style.display = 'flex';
                } else {
                    alert('Error fetching budget details: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while fetching budget details');
            });
        });
    });
    
    // Delete budget buttons
    const deleteBudgetButtons = document.querySelectorAll('.delete-budget');
    deleteBudgetButtons.forEach(button => {
        button.addEventListener('click', function() {
            const budgetId = this.getAttribute('data-id');
            
            if (confirm('Are you sure you want to delete this budget?')) {
                fetch(`/budget/${budgetId}`, {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Reload page to update budget list
                        window.location.reload();
                    } else {
                        alert('Error deleting budget: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while deleting the budget');
                });
            }
        });
    });
    
    // Export data button
    if (exportDataBtn) {
        exportDataBtn.addEventListener('click', function() {
            window.location.href = '/export-data';
        });
    }
    
    // Delete account button
    if (deleteAccountBtn) {
        deleteAccountBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
                if (confirm('All your data will be permanently deleted. Are you absolutely sure?')) {
                    fetch('/delete-account', {
                        method: 'POST'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Your account has been deleted. You will be redirected to the homepage.');
                            window.location.href = '/';
                        } else {
                            alert('Error deleting account: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while deleting your account');
                    });
                }
            }
        });
    }
});