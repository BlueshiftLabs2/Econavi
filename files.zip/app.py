    return render_template('dashboard.html', 
                         username=session['username'], 
                         expenses=expenses,
                         category_totals=category_totals,
                         total_expenses=total_expenses,
                         budget_remaining=budget_remaining,
                         upcoming_bills=upcoming_bills)

@app.route('/add-expense', methods=['POST'])
def add_expense():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    try:
        amount = float(request.form['amount'])
        category = request.form['category']
        description = request.form['description']
        date = request.form['date']
        
        success = Expense.create(session['user_id'], amount, category, description, date)
        
        if success:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Failed to add expense'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/add-budget', methods=['POST'])
def add_budget():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    try:
        category = request.form['category']
        amount = float(request.form['amount'])
        period = request.form['period']
        
        success = Budget.create(session['user_id'], category, amount, period)
        
        if success:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Failed to add budget'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/settings')
def settings():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.get_by_id(session['user_id'])
    budgets = Budget.get_all(session['user_id'])
    
    return render_template('settings.html', 
                          username=session['username'],
                          email=user['email'],
                          budgets=budgets)

@app.route('/update-profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    try:
        username = request.form['username']
        email = request.form['email']
        current_password = request.form.get('current_password', '')
        new_password = request.form.get('new_password', '')
        
        # Get current user
        user = User.get_by_id(session['user_id'])
        
        # Check if email already exists for another user
        existing_user = User.get_by_email(email)
        if existing_user and existing_user['id'] != session['user_id']:
            return jsonify({'success': False, 'message': 'Email already in use by another account'})
        
        # Update profile
        if new_password:
            # If changing password, verify current password
            if not User.check_password(user, current_password):
                return jsonify({'success': False, 'message': 'Current password is incorrect'})
            
            # Update user with new password
            User.update_profile(session['user_id'], username, email)
            User.update_password(session['user_id'], new_password)
        else:
            # Update user without changing password
            User.update_profile(session['user_id'], username, email)
        
        # Update session username
        session['username'] = username
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/update-notifications', methods=['POST'])
def update_notifications():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    # In a real application, you would store these preferences in your database
    # For this example, we'll just return success
    return jsonify({'success': True})

@app.route('/budget/<int:budget_id>', methods=['GET', 'DELETE'])
def manage_budget(budget_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    # Verify budget belongs to user
    budget = Budget.get_by_id(budget_id, session['user_id'])
    
    if not budget:
        return jsonify({'success': False, 'message': 'Budget not found or access denied'})
    
    if request.method == 'GET':
        # Return budget details
        budget_dict = {
            'id': budget['id'],
            'category': budget['category'],
            'amount': budget['amount'],
            'period': budget['period']
        }
        return jsonify({'success': True, 'budget': budget_dict})
    
    elif request.method == 'DELETE':
        # Delete budget
        success = Budget.delete(budget_id, session['user_id'])
        if success:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Failed to delete budget'})

@app.route('/add-income', methods=['POST'])
def add_income():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    try:
        amount = float(request.form['amount'])
        source = request.form['source']
        description = request.form['description']
        date = request.form['date']
        
        success = Income.create(session['user_id'], amount, source, description, date)
        
        if success:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Failed to add income'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/add-bill', methods=['POST'])
def add_bill():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    try:
        name = request.form['name']
        amount = float(request.form['amount'])
        due_date = request.form['due_date']
        category = request.form['category']
        is_recurring = 'is_recurring' in request.form
        recurrence_period = request.form.get('recurrence_period') if is_recurring else None
        
        success = Bill.create(
            session['user_id'], 
            name, 
            amount, 
            due_date, 
            category, 
            is_recurring, 
            recurrence_period
        )
        
        if success:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Failed to add bill'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/export-data')
def export_data():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get user data
    expenses = Expense.get_recent(session['user_id'], limit=1000)  # Get up to 1000 recent expenses
    
    # Create CSV data for expenses
    expense_csv = 'Date,Category,Description,Amount\n'
    for expense in expenses:
        # Clean description to avoid CSV issues
        description = expense['description'].replace('"', '""') if expense['description'] else ""
        expense_csv += f'{expense["date"]},{expense["category"]},"{description}",{expense["amount"]}\n'
    
    # Create response with CSV attachment
    response = make_response(expense_csv)
    response.headers['Content-Disposition'] = 'attachment; filename=econavi_expenses.csv'
    response.headers['Content-Type'] = 'text/csv'
    
    return response

@app.route('/delete-account', methods=['POST'])
def delete_account():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    try:
        success = User.delete(session['user_id'])
        
        if success:
            # Clear session
            session.clear()
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Failed to delete account'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/ask-ai', methods=['POST'])
def ask_ai():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'})
    
    query = request.form['query']
    
    # Get user's financial data for context
    expenses = Expense.get_recent(session['user_id'], limit=20)
    budgets = Budget.get_all(session['user_id'])
    total_income = Income.get_total(session['user_id'])
    
    # Format data for the AI
    expense_data = [dict(e) for e in expenses]
    budget_data = [dict(b) for b in budgets]
    
    # Prepare prompt for Gemini
    prompt = f"""
    As Econavi's AI financial assistant, analyze the following financial data and answer this user query:
    "{query}"
    
    User's recent expenses: {expense_data}
    User's total income: ${total_income}
    User's budget: {budget_data}
    
    Provide helpful, specific financial advice based on this data.
    """
    
    try:
        # Get response from Gemini
        response = model.generate_content(prompt)
        
        return jsonify({'success': True, 'response': response.text})
    except Exception as e:
        return jsonify({'success': False, 'message': f"AI error: {str(e)}"})

@app.route('/analytics')
def analytics():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get expense data by month for the last 6 months
    today = datetime.date.today()
    month_data = []
    
    for i in range(5, -1, -1):
        # Calculate start and end of month
        month_date = today.replace(day=1) - datetime.timedelta(days=i * 30)
        month_start = month_date.replace(day=1).isoformat()
        
        if month_date.month == 12:
            month_end = month_date.replace(year=month_date.year + 1, month=1, day=1)
        else:
            month_end = month_date.replace(month=month_date.month + 1, day=1)
        month_end = (month_end - datetime.timedelta(days=1)).isoformat()
        
        # Get expenses for this month
        month_expenses = Expense.get_by_date_range(session['user_id'], month_start, month_end)
        month_total = sum(expense['amount'] for expense in month_expenses)
        
        month_data.append({
            'month': month_date.strftime('%b %Y'),
            'total': month_total,
            'expenses': month_expenses
        })
    
    # Get category totals
    category_totals = Expense.get_category_totals(session['user_id'])
    
    # Get total expenses and income
    total_expenses = Expense.get_total(session['user_id'])
    total_income = Income.get_total(session['user_id'])
    savings_rate = ((total_income - total_expenses) / total_income * 100) if total_income > 0 else 0
    
    return render_template('analytics.html',
                          username=session['username'],
                          month_data=month_data,
                          category_totals=category_totals,
                          total_expenses=total_expenses,
                          total_income=total_income,
                          savings_rate=savings_rate)

if __name__ == '__main__':
    app.run(debug=True)